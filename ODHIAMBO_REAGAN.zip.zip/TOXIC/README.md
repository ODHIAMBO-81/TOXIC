
School Timetable (HTML & CSS Project)

 Project Description
This project is a simple *school timetable* created using *HTML* and *CSS*. It visually represents a weekly class schedule from *Monday to Friday*, listing subjects across different time slots. The focus was on table structure, semantic tags, and basic styling for readability and structure.

 Purpose
The purpose of this timetable is to:
- Practice HTML table structuring
- Represent weekly class schedules
- Understand how to manage rows, columns, and cell spans
- Apply basic CSS for layout and responsiveness

 File Structure


school-timetable/
├── index.html    # Main file with HTML structure
└── style.css     # Styling applied to the timetable


 Features
- Structured timetable using <table>, <thead>, <tbody>, <tr>, <th>, and <td>
- Time slots and subjects for each day (Monday–Friday)
- Use of rowspan and colspan for clean layout
- Responsive adjustments for better viewing on small screens

 Technologies Used
- HTML5
- CSS3

 How to Use
1. Clone or download the repository.
2. Open index.html in your browser.
3. View the complete weekly timetable.

